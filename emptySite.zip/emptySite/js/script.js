const scrollMenu = (side) => {
    let scrollPos = $('#menu2').scrollLeft();

    $('#menu2').scrollLeft(side === 'l' ? scrollPos + 200 : scrollPos - 200);
}

const scrollMenuFull = (side) => {
    let scrollPos = $('#menu2').scrollLeft();

    let totalW = $('#menu2').css('width').split('px')[0];

    $('#menu2').scrollLeft(side === 'l' ? scrollPos + totalW : 0);
}

const showHideMenu = () => {
    let isShowing = $('#menu3').css('height') !== '0px';

    $('#menu3').css('height', isShowing === true ? '0px' : 'fit-content');
    $('#menu3').css('padding', isShowing === true ? '0px' : '3% 4%');
    $('#menu3-itens-wrap').css('display', isShowing === true ? 'none' : 'block')
}
